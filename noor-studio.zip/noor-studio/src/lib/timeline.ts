import { FPS, VideoProps } from '../types';

export type SceneSpec = {
  kind: 'intro' | 'question' | 'content';
  from: number;
  duration: number;
  text?: string;
  index: number; // content scene index (0-based), -1 for intro/question
  count: number; // total content scenes
};

export const splitParagraphs = (t: string) => t.split(/\n+/).map((s) => s.trim()).filter(Boolean);
const wc = (t: string) => t.trim().split(/\s+/).filter(Boolean).length;

/** Splits total duration between scenes, weighted by amount of text. */
export function buildTimeline(p: Pick<VideoProps, 'duration' | 'body' | 'question'>) {
  const total = Math.max(10, p.duration) * FPS;
  const paras = splitParagraphs(p.body);
  const specs = [
    { kind: 'intro' as const, text: undefined, w: 14 },
    { kind: 'question' as const, text: p.question, w: 10 + wc(p.question) * 1.2 },
    ...paras.map((t) => ({ kind: 'content' as const, text: t, w: 6 + wc(t) * 1.2 })),
  ];
  const sum = specs.reduce((a, s) => a + s.w, 0);
  let from = 0;
  const scenes: SceneSpec[] = specs.map((s, i) => {
    const duration = Math.max(75, Math.round((total * s.w) / sum));
    const spec = { kind: s.kind, text: s.text, from, duration, index: i - 2, count: paras.length };
    from += duration;
    return spec;
  });
  return { scenes, total: from };
}

/** Comfortable reading time (~2.6 words/s + settling time per scene). */
export function suggestedSeconds(p: Pick<VideoProps, 'body' | 'question'>) {
  const paras = splitParagraphs(p.body);
  return Math.ceil(4 + 2 + wc(p.question) / 2.6 + paras.reduce((a, t) => a + 1.5 + wc(t) / 2.6, 0));
}
