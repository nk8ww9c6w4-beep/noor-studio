import React, { useMemo, useState } from 'react';
import { Player } from '@remotion/player';
import { IslamicVideo } from './remotion/IslamicVideo';
import { DEFAULT_PROPS } from './defaultData';
import { buildTimeline, splitParagraphs, suggestedSeconds } from './lib/timeline';
import { loadImage } from './lib/image';
import { FPS, HEIGHT, WIDTH, VideoProps } from './types';

const input = 'w-full rounded-md border border-neutral-300 bg-white px-3 py-2 text-sm focus:border-black focus:outline-none';
const Field: React.FC<{ label: string; hint?: string; children: React.ReactNode }> = ({ label, hint, children }) => (
  <label className="block">
    <span className="mb-1 block text-xs font-bold text-neutral-800">{label}</span>
    {children}
    {hint && <span className="mt-1 block text-xs text-neutral-500">{hint}</span>}
  </label>
);

export const App: React.FC = () => {
  const [p, setP] = useState<VideoProps>(DEFAULT_PROPS);
  const [rendering, setRendering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = <K extends keyof VideoProps>(k: K, v: VideoProps[K]) => setP((s) => ({ ...s, [k]: v }));
  const { total } = useMemo(() => buildTimeline(p), [p]);
  const scenes = splitParagraphs(p.body).length;
  const need = suggestedSeconds(p);

  const upload = (k: 'scholarImage' | 'logoImage') => async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) set(k, await loadImage(f, k === 'scholarImage' ? 1400 : 800, k === 'scholarImage' ? 'image/jpeg' : 'image/png'));
  };

  const render = async () => {
    setRendering(true); setError(null);
    try {
      const r = await fetch('/api/render', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(p) });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error ?? 'Render failed');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(await r.blob());
      a.download = 'islamic-video.mp4';
      a.click();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Render failed. Is the render server running? (npm run dev)');
    } finally { setRendering(false); }
  };

  return (
    <div className="flex h-screen bg-neutral-200 font-sans text-neutral-900">
      <aside className="w-[440px] shrink-0 space-y-5 overflow-y-auto border-r border-neutral-300 bg-neutral-50 p-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-black tracking-tight">Noor Studio</h1>
          <button onClick={() => setP(DEFAULT_PROPS)} className="rounded-md bg-black px-3 py-2 text-xs font-bold text-white hover:bg-neutral-700">
            Load default template
          </button>
        </div>

        <Field label="Video title" hint="Small heading at the top of scene 1">
          <input className={input} value={p.title} onChange={(e) => set('title', e.target.value)} />
        </Field>
        <Field label="Subtitle / large heading">
          <input className={input} value={p.subtitle} onChange={(e) => set('subtitle', e.target.value)} />
        </Field>
        <Field label="Scholar name">
          <input className={input} value={p.scholarName} onChange={(e) => set('scholarName', e.target.value)} />
        </Field>
        <Field label="Question (scene 2)" hint="Wrap words in *asterisks* to make them larger.">
          <textarea rows={3} className={input} value={p.question} onChange={(e) => set('question', e.target.value)} />
        </Field>
        <Field label={`Main text (${scenes} content scenes)`} hint="Each paragraph becomes one scene. Use *asterisks* to highlight. Without them, the longest words are highlighted.">
          <textarea rows={10} className={input} value={p.body} onChange={(e) => set('body', e.target.value)} />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Scholar image"><input type="file" accept="image/*" onChange={upload('scholarImage')} className="w-full text-xs" /></Field>
          <Field label="Logo / calligraphy"><input type="file" accept="image/*" onChange={upload('logoImage')} className="w-full text-xs" /></Field>
        </div>
        {(p.scholarImage || p.logoImage) && (
          <div className="flex gap-3 text-xs">
            {p.scholarImage && <button className="underline" onClick={() => set('scholarImage', null)}>Remove scholar image</button>}
            {p.logoImage && <button className="underline" onClick={() => set('logoImage', null)}>Remove logo</button>}
          </div>
        )}

        <Field label={`Duration: ${p.duration}s`} hint={p.duration < need ? `Text may be hard to read. Suggested: ${need}s or more.` : `Comfortable reading pace (minimum about ${need}s).`}>
          <div className="flex items-center gap-3">
            <input type="range" min={15} max={180} value={p.duration} onChange={(e) => set('duration', +e.target.value)} className="w-full accent-black" />
            <button className="shrink-0 text-xs underline" onClick={() => set('duration', Math.max(15, need))}>Auto</button>
          </div>
        </Field>
        <Field label={`Font size: ${Math.round(p.fontScale * 100)}%`}>
          <input type="range" min={0.7} max={1.5} step={0.05} value={p.fontScale} onChange={(e) => set('fontScale', +e.target.value)} className="w-full accent-black" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Background"><input type="color" value={p.bgColor} onChange={(e) => set('bgColor', e.target.value)} className="h-9 w-full" /></Field>
          <Field label="Ink / shapes"><input type="color" value={p.inkColor} onChange={(e) => set('inkColor', e.target.value)} className="h-9 w-full" /></Field>
        </div>

        <button disabled={rendering} onClick={render} className="w-full rounded-md bg-black py-3 text-sm font-bold text-white hover:bg-neutral-700 disabled:opacity-50">
          {rendering ? 'Rendering MP4… this can take a few minutes' : 'Render and download MP4'}
        </button>
        {error && <p className="text-xs text-red-700">{error}</p>}
        <p className="text-xs text-neutral-500">{(total / FPS).toFixed(1)}s total · {WIDTH}×{HEIGHT} · {FPS} fps</p>
      </aside>

      <main className="flex min-w-0 flex-1 items-center justify-center p-6">
        <div className="overflow-hidden rounded-xl shadow-2xl" style={{ height: 'calc(100vh - 48px)', aspectRatio: '9 / 16' }}>
          <Player
            component={IslamicVideo}
            inputProps={p}
            durationInFrames={total}
            fps={FPS}
            compositionWidth={WIDTH}
            compositionHeight={HEIGHT}
            controls
            loop
            style={{ width: '100%', height: '100%' }}
          />
        </div>
      </main>
    </div>
  );
};
