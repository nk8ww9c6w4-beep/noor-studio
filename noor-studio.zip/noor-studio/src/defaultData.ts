import type { VideoProps } from './types';

export const DEFAULT_PROPS: VideoProps = {
  title: 'How to reach the level of',
  subtitle: 'a scholar',
  scholarName: "Imam al-Shafi'i",
  question:
    "Someone asks: how did the *great scholars* get there, when I can't even keep up with a *study programme*?",
  body: [
    'The scholars did not begin as *scholars*. They began as students who showed up *every single day*.',
    'They travelled for *years* in search of knowledge. Their secret was never talent. It was *consistency*.',
    'Start small. Read *one page*. Memorise *one line*. Review it *tomorrow*. Small steps, repeated, build *mountains*.',
    'Sit with *the people of knowledge*. Ask questions, respect your teachers and keep your *intention sincere*.',
    'The Prophet (peace be upon him) said that whoever takes a path to seek knowledge, Allah eases for them a path to *Jannah*.',
  ].join('\n\n'),
  scholarImage: null,
  logoImage: null,
  duration: 45,
  fontScale: 1,
  bgColor: '#f1f1ee',
  inkColor: '#0c0c0c',
};
