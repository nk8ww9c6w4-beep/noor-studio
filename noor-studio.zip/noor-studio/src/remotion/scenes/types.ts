import { VideoProps } from '../../types';
import { SceneSpec } from '../../lib/timeline';

export type SceneProps = { p: VideoProps; spec: SceneSpec };
