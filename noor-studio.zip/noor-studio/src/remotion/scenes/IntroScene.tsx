import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { SceneProps } from './types';
import { SceneFade } from '../components/SceneFade';
import { Shape } from '../components/Shape';
import { ScholarImage } from '../components/ScholarImage';
import { fontFamily } from '../font';

export const IntroScene: React.FC<SceneProps> = ({ p, spec }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const sp = (d: number, config = { damping: 18, stiffness: 120 }) => spring({ frame: frame - d, fps, config });
  const a = sp(4), b = sp(14, { damping: 14, stiffness: 90 }), c = sp(26, { damping: 200, stiffness: 60 }), l = sp(44);
  const fs = Math.min(230, 1700 / Math.max(p.subtitle.length, 6)) * p.fontScale;
  const zoom = interpolate(frame, [0, spec.duration], [1.08, 1]);
  const blur = interpolate(c, [0, 1], [24, 0]);

  return (
    <SceneFade duration={spec.duration}>
      <Shape variant="middle" frame={spec.from + frame} ink={p.inkColor} />
      <div style={{ position: 'absolute', left: 100, right: 100, top: 190, fontFamily, color: p.inkColor }}>
        <div style={{ fontSize: 50 * p.fontScale, fontWeight: 700, letterSpacing: '-0.02em', opacity: a, transform: `translateY(${(1 - a) * -30}px)`, filter: `blur(${(1 - a) * 8}px)` }}>
          {p.title}
        </div>
        <div style={{ marginTop: 14, fontSize: fs, fontWeight: 900, lineHeight: 0.92, letterSpacing: '-0.05em', opacity: Math.min(1, b * 1.4), transform: `scale(${interpolate(b, [0, 1], [1.18, 1])})`, transformOrigin: 'left top', filter: `blur(${Math.max(0, (1 - b) * 20)}px)` }}>
          {p.subtitle}
        </div>
      </div>
      <div style={{ position: 'absolute', left: 130, top: 800, width: 820, height: 900, opacity: c, filter: `blur(${blur}px)` }}>
        <ScholarImage src={p.scholarImage} ink={p.inkColor} scale={zoom} />
      </div>
      <div style={{ position: 'absolute', left: 130, top: 1590, minWidth: 420, padding: '30px 44px', background: p.inkColor, color: '#fff', fontFamily, fontWeight: 900, fontSize: 52 * Math.min(1, p.fontScale), letterSpacing: '-0.01em', opacity: l, transform: `translateY(${(1 - l) * 60}px)` }}>
        {p.scholarName}
      </div>
    </SceneFade>
  );
};
