import React from 'react';
import { spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { SceneProps } from './types';
import { SceneFade } from '../components/SceneFade';
import { Shape, ShapeVariant } from '../components/Shape';
import { KineticText } from '../components/KineticText';
import { fontFamily } from '../font';

const LAYOUTS: { shape: ShapeVariant; align: 'left' | 'center'; justify: string }[] = [
  { shape: 'bottomRight', align: 'left', justify: 'center' },
  { shape: 'topLeft', align: 'center', justify: 'center' },
  { shape: 'bottomLeft', align: 'left', justify: 'flex-end' },
];

export const ContentScene: React.FC<SceneProps> = ({ p, spec }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const text = spec.text ?? '';
  const L = LAYOUTS[spec.index % LAYOUTS.length];
  const prog = spring({ frame: frame - 6, fps, config: { damping: 200 } });
  const len = text.length;
  const base = len > 260 ? 56 : len > 160 ? 66 : len > 90 ? 76 : 88;

  return (
    <SceneFade duration={spec.duration}>
      <Shape variant={L.shape} frame={spec.from + frame} ink={p.inkColor} />
      <div style={{ position: 'absolute', left: 100, right: 100, top: 190, display: 'flex', alignItems: 'center', gap: 24, fontFamily, color: p.inkColor, fontWeight: 700, fontSize: 34 }}>
        <span>{spec.index + 1}/{spec.count}</span>
        <div style={{ height: 2, width: 700 * prog * ((spec.index + 1) / spec.count), background: p.inkColor }} />
      </div>
      <div style={{ position: 'absolute', left: 100, right: 100, top: 300, bottom: 360, display: 'flex', flexDirection: 'column', justifyContent: L.justify, alignItems: L.align === 'center' ? 'center' : 'flex-start' }}>
        <KineticText text={text} size={base * p.fontScale} ink={p.inkColor} delay={10} align={L.align} />
      </div>
    </SceneFade>
  );
};
