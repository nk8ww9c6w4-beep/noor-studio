import React from 'react';
import { spring, interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { SceneProps } from './types';
import { SceneFade } from '../components/SceneFade';
import { Shape } from '../components/Shape';
import { KineticText } from '../components/KineticText';
import { RadialPattern } from '../components/RadialPattern';
import { fontFamily } from '../font';
import { Img } from 'remotion';

const Star: React.FC<{ ink: string }> = ({ ink }) => (
  <svg viewBox="0 0 100 100" width="62%" height="62%">
    {[0, 45].map((r) => <rect key={r} x="18" y="18" width="64" height="64" fill="none" stroke={ink} strokeWidth="1.4" transform={`rotate(${r} 50 50)`} />)}
    <circle cx="50" cy="50" r="12" fill={ink} />
  </svg>
);

export const QuestionScene: React.FC<SceneProps> = ({ p, spec }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const name = spring({ frame: frame - 4, fps, config: { damping: 16 } });
  const rule = spring({ frame: frame - 14, fps, config: { damping: 200 } });
  const logo = spring({ frame: frame - 30, fps, config: { damping: 15, stiffness: 80 } });
  const nameSize = Math.min(130, 1500 / Math.max(p.scholarName.length, 6)) * p.fontScale;
  const cy = 1430, S = 430;

  return (
    <SceneFade duration={spec.duration}>
      <Shape variant="bottomRight" frame={spec.from + frame} ink={p.inkColor} />
      <div style={{ position: 'absolute', left: 100, right: 100, top: 190, fontFamily, color: p.inkColor, fontSize: nameSize, fontWeight: 900, lineHeight: 0.95, letterSpacing: '-0.05em', opacity: name, transform: `translateY(${(1 - name) * 40}px)`, filter: `blur(${(1 - name) * 10}px)` }}>
        {p.scholarName}
      </div>
      <div style={{ position: 'absolute', left: 100, top: 190 + nameSize * 1.1 + 24, height: 3, width: 880 * rule, background: p.inkColor }} />
      <div style={{ position: 'absolute', left: 100, top: 190 + nameSize * 1.1 + 80 }}>
        <KineticText text={p.question} size={62 * p.fontScale} ink={p.inkColor} delay={22} />
      </div>
      <div style={{ position: 'absolute', left: 540 - 480, top: cy - 480, opacity: logo }}>
        <RadialPattern size={960} frame={spec.from + frame} color={p.inkColor} opacity={0.4} draw={interpolate(logo, [0, 1], [0.6, 1])} />
      </div>
      <div style={{ position: 'absolute', left: 540 - S / 2, top: cy - S / 2, width: S, height: S, borderRadius: '50%', background: p.bgColor, border: `3px solid ${p.inkColor}`, overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: logo, transform: `scale(${interpolate(logo, [0, 1], [0.7, 1])})` }}>
        {p.logoImage ? <Img src={p.logoImage} style={{ width: '76%', height: '76%', objectFit: 'contain' }} /> : <Star ink={p.inkColor} />}
      </div>
    </SceneFade>
  );
};
