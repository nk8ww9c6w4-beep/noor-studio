import React from 'react';
import { AbsoluteFill, Sequence } from 'remotion';
import { VideoProps } from '../types';
import { buildTimeline } from '../lib/timeline';
import { Backdrop } from './components/Backdrop';
import { IntroScene } from './scenes/IntroScene';
import { QuestionScene } from './scenes/QuestionScene';
import { ContentScene } from './scenes/ContentScene';

export const IslamicVideo: React.FC<VideoProps> = (p) => {
  const { scenes } = buildTimeline(p);
  return (
    <AbsoluteFill>
      <Backdrop bg={p.bgColor} ink={p.inkColor} />
      {scenes.map((s) => (
        <Sequence key={s.from} from={s.from} durationInFrames={s.duration}>
          {s.kind === 'intro' && <IntroScene p={p} spec={s} />}
          {s.kind === 'question' && <QuestionScene p={p} spec={s} />}
          {s.kind === 'content' && <ContentScene p={p} spec={s} />}
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
