import React from 'react';
import { Composition } from 'remotion';
import { IslamicVideo } from './IslamicVideo';
import { DEFAULT_PROPS } from '../defaultData';
import { buildTimeline } from '../lib/timeline';
import { FPS, HEIGHT, WIDTH, VideoProps } from '../types';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="IslamicVideo"
    component={IslamicVideo}
    width={WIDTH}
    height={HEIGHT}
    fps={FPS}
    durationInFrames={buildTimeline(DEFAULT_PROPS).total}
    defaultProps={DEFAULT_PROPS as VideoProps}
    calculateMetadata={({ props }) => ({ durationInFrames: buildTimeline(props).total })}
  />
);
