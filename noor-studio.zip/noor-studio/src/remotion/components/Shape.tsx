import React from 'react';
import { useVideoConfig } from 'remotion';

export type ShapeVariant = 'middle' | 'bottomRight' | 'topLeft' | 'bottomLeft';

const PATH =
  'M-520 -60 C-420 -260 -120 -300 80 -180 C280 -60 480 -260 560 -80 C620 70 420 240 160 220 C-60 200 -160 330 -340 280 C-500 240 -600 100 -520 -60 Z';
const POS: Record<ShapeVariant, [number, number, number, number]> = {
  middle: [540, 1000, 1.3, -8],
  bottomRight: [980, 1800, 1.0, 20],
  topLeft: [90, 120, 0.9, 200],
  bottomLeft: [80, 1790, 1.0, -160],
};

/** Large abstract black curved shape that drifts slowly. `frame` is the global video frame. */
export const Shape: React.FC<{ variant: ShapeVariant; frame: number; ink: string }> = ({ variant, frame, ink }) => {
  useVideoConfig();
  const [x, y, s, r] = POS[variant];
  const dx = Math.sin(frame / 55) * 55, dy = Math.cos(frame / 70) * 35, dr = Math.sin(frame / 90) * 5;
  return (
    <svg width="1080" height="1920" style={{ position: 'absolute', inset: 0 }}>
      <path d={PATH} fill={ink} transform={`translate(${x + dx} ${y + dy}) rotate(${r + dr}) scale(${s * 1.15} ${s})`} />
    </svg>
  );
};
