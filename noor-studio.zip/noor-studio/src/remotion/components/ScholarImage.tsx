import React from 'react';
import { Img } from 'remotion';

/** Scholar photo, desaturated, edges faded with a mask. Falls back to a silhouette. */
export const ScholarImage: React.FC<{ src: string | null; ink: string; scale?: number }> = ({ src, ink, scale = 1 }) => {
  const mask = 'linear-gradient(to bottom, transparent 0%, #000 22%, #000 70%, transparent 100%)';
  return (
    <div style={{ width: '100%', height: '100%', overflow: 'hidden', WebkitMaskImage: mask, maskImage: mask }}>
      {src ? (
        <Img src={src} style={{ width: '100%', height: '100%', objectFit: 'cover', filter: 'grayscale(1) contrast(1.05)', transform: `scale(${scale})` }} />
      ) : (
        <svg viewBox="0 0 400 440" width="100%" height="100%" preserveAspectRatio="xMidYMid slice" style={{ transform: `scale(${scale})` }}>
          <defs><linearGradient id="sg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#cfcfcb" /><stop offset="1" stopColor="#9a9a96" /></linearGradient></defs>
          <rect width="400" height="440" fill="url(#sg)" />
          <circle cx="200" cy="160" r="72" fill={ink} opacity="0.85" />
          <path d="M40 440 C40 300 120 250 200 250 C280 250 360 300 360 440 Z" fill={ink} opacity="0.85" />
        </svg>
      )}
    </div>
  );
};
