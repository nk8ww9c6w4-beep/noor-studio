import React from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame } from 'remotion';

/** Smooth transition: blur + fade + slide on entry and exit of every scene. */
export const SceneFade: React.FC<{ duration: number; children: React.ReactNode }> = ({ duration, children }) => {
  const f = useCurrentFrame();
  const T = 14;
  const inn = interpolate(f, [0, T], [0, 1], { extrapolateRight: 'clamp' });
  const out = interpolate(f, [duration - T, duration], [1, 0], { extrapolateLeft: 'clamp' });
  const o = Math.min(inn, out);
  return (
    <AbsoluteFill style={{ opacity: o, filter: `blur(${(1 - o) * 12}px)`, transform: `translateY(${(1 - inn) * 36 - (1 - out) * 36}px)` }}>
      {children}
    </AbsoluteFill>
  );
};
