import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { RadialPattern } from './RadialPattern';

/** Persistent background: gray gradient, thin geometric lines, rotating rosette, paper grain. */
export const Backdrop: React.FC<{ bg: string; ink: string }> = ({ bg, ink }) => {
  const f = useCurrentFrame();
  const line = { stroke: ink, strokeOpacity: 0.08, strokeWidth: 1.5, fill: 'none' } as const;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(165deg, ${bg} 0%, #dcdcd8 120%)` }}>
      <AbsoluteFill style={{ background: 'radial-gradient(circle at 80% 12%, rgba(255,255,255,.7), transparent 55%)' }} />
      <svg width="1080" height="1920" style={{ position: 'absolute' }}>
        {[135, 945].map((x) => <line key={x} x1={x} x2={x} y1={0} y2={1920} {...line} />)}
        {[170, 1750].map((y) => <line key={y} x1={0} x2={1080} y1={y} y2={y} {...line} />)}
        <circle cx={540} cy={960} r={470 + Math.sin(f / 60) * 6} {...line} />
        <line x1={0} y1={1920} x2={1080} y2={0} {...line} strokeOpacity={0.05} />
      </svg>
      <div style={{ position: 'absolute', left: 540, top: -140 }}>
        <div style={{ position: 'absolute', transform: 'translate(-50%,-50%)' }}>
          <RadialPattern size={900} frame={f} color={ink} opacity={0.07} />
        </div>
      </div>
      <svg width="100%" height="100%" style={{ position: 'absolute', mixBlendMode: 'multiply', opacity: 0.16 }}>
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};
