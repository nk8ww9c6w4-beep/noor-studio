import React from 'react';

/** 12-fold overlapping-circle rosette with concentric rings. Rotates slowly with `frame`. */
export const RadialPattern: React.FC<{ size: number; frame: number; color: string; opacity?: number; draw?: number }> = ({
  size, frame, color, opacity = 0.3, draw = 1,
}) => {
  const c = size / 2;
  const r = size * 0.16;
  const stroke = { stroke: color, strokeWidth: 1.6, fill: 'none', strokeOpacity: opacity } as const;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ opacity: draw }}>
      <g transform={`rotate(${frame * 0.12} ${c} ${c})`}>
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return <circle key={i} cx={c + Math.cos(a) * r * 1.9} cy={c + Math.sin(a) * r * 1.9} r={r * draw} {...stroke} />;
        })}
      </g>
      <g transform={`rotate(${-frame * 0.08} ${c} ${c})`}>
        {Array.from({ length: 36 }).map((_, i) => {
          const a = (i / 36) * Math.PI * 2;
          const r1 = size * 0.4, r2 = size * (i % 3 === 0 ? 0.49 : 0.45);
          return <line key={i} x1={c + Math.cos(a) * r1} y1={c + Math.sin(a) * r1} x2={c + Math.cos(a) * r2} y2={c + Math.sin(a) * r2} {...stroke} />;
        })}
      </g>
      {[0.4, 0.34, 0.2].map((k) => <circle key={k} cx={c} cy={c} r={size * k * draw} {...stroke} />)}
    </svg>
  );
};
