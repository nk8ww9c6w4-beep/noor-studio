import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { fontFamily } from '../font';

type Tok = { t: string; imp: boolean };

/** Words wrapped in *asterisks* are emphasised. If none are marked, the longest words are chosen. */
export function tokenize(text: string): Tok[] {
  let on = false;
  const toks = text.split(/\s+/).filter(Boolean).map((r) => {
    if (r.startsWith('*')) on = true;
    const imp = on;
    if (/\*\W*$/.test(r)) on = false;
    return { t: r.replace(/\*/g, ''), imp };
  });
  if (!toks.some((k) => k.imp)) {
    toks
      .map((k, i) => ({ i, n: k.t.replace(/[^\p{L}]/gu, '').length }))
      .filter((k) => k.n >= 7)
      .sort((a, b) => b.n - a.n)
      .slice(0, 2)
      .forEach((k) => (toks[k.i].imp = true));
  }
  return toks;
}

const Word: React.FC<{ tok: Tok; delay: number; size: number; impSize: number; ink: string; soft: string }> = ({
  tok, delay, size, impSize, ink, soft,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({
    frame: frame - delay - (tok.imp ? 4 : 0),
    fps,
    config: tok.imp ? { damping: 9, stiffness: 110 } : { damping: 18, stiffness: 140 },
  });
  const blur = interpolate(s, [0, 1], [tok.imp ? 18 : 8, 0], { extrapolateRight: 'clamp', extrapolateLeft: 'clamp' });
  const scale = tok.imp ? interpolate(s, [0, 1], [0.6, 1]) : interpolate(s, [0, 1], [0.92, 1]);
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily,
        fontSize: tok.imp ? impSize : size,
        fontWeight: tok.imp ? 900 : 700,
        letterSpacing: tok.imp ? '-0.04em' : '-0.015em',
        lineHeight: 1.05,
        color: tok.imp ? ink : soft,
        opacity: Math.min(1, Math.max(0, s * 1.6)),
        filter: `blur(${blur}px)`,
        transform: `translateY(${(1 - s) * 28}px) scale(${scale})`,
        transformOrigin: 'left bottom',
      }}
    >
      {tok.t}
    </span>
  );
};

export const KineticText: React.FC<{
  text: string; size: number; ink: string; delay?: number; align?: 'left' | 'center'; maxWidth?: number;
}> = ({ text, size, ink, delay = 0, align = 'left', maxWidth = 880 }) => {
  const toks = tokenize(text);
  const stagger = Math.min(4, 90 / Math.max(1, toks.length));
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'baseline', columnGap: size * 0.28, rowGap: size * 0.14, justifyContent: align === 'center' ? 'center' : 'flex-start', maxWidth }}>
      {toks.map((tok, i) => {
        const longest = tok.t.length * 0.62;
        const impSize = Math.max(size * 1.05, Math.min(size * 1.5, maxWidth / longest));
        return <Word key={i} tok={tok} delay={delay + i * stagger} size={size} impSize={impSize} ink={ink} soft="#3b3b3b" />;
      })}
    </div>
  );
};
