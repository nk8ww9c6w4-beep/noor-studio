import { loadFont } from '@remotion/google-fonts/Inter';

export const { fontFamily } = loadFont('normal', {
  weights: ['700', '900'],
  subsets: ['latin', 'latin-ext'], // latin-ext covers Albanian ë, ç
});
