export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

export type VideoProps = {
  title: string;        // small heading, scene 1
  subtitle: string;     // large heading, scene 1
  scholarName: string;
  question: string;     // scene 2 text. Wrap words in *asterisks* to emphasise
  body: string;         // one paragraph (line) = one scene
  scholarImage: string | null;
  logoImage: string | null;
  duration: number;     // seconds
  fontScale: number;    // 0.7 – 1.5
  bgColor: string;
  inkColor: string;
};
