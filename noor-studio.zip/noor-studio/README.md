# Noor Studio

A web editor for vertical (1080×1920, 9:16, 30 fps) Islamic educational videos with a minimalist black / off-white style. Built with React, TypeScript, Tailwind CSS and Remotion. Exports MP4.

## Requirements
- Node.js 18 or newer (20 recommended)
- Internet on first run (Remotion downloads a headless Chrome the first time you render, and Inter is loaded from Google Fonts)
- FFmpeg is bundled with Remotion, so you don't need to install it

## Install and run
```bash
npm install
npm run dev
```
Open http://localhost:5173. `npm run dev` starts two things:
- the Vite editor on port 5173 (editing and live preview)
- a small Express render server on port 3001 (MP4 export)

If npm reports a Remotion version mismatch, pin every `remotion` and `@remotion/*` package in `package.json` to the same exact version (for example `4.0.xyz`) and reinstall.

## Using the editor
1. Press **Load default template** to see the full example design.
2. Fill in title, subtitle (the large heading), scholar name, question and main text.
3. Upload a scholar photo and a logo or calligraphy image. Both are optional; a silhouette and a geometric star appear if they are missing.
4. Set duration and font size. The editor suggests a comfortable minimum duration from the amount of text.
5. Press **Render and download MP4**. Rendering takes about 1–5 minutes, depending on length.

**Scenes:** Scene 1 is the introduction, scene 2 is the question, and every paragraph (separated by a new line) of the main text becomes its own scene. Time is divided between scenes by text length.

**Emphasis:** wrap words in asterisks, e.g. `build *mountains*` or `*the people of knowledge*`, to make them larger and sharper. Without asterisks, the longest words are highlighted automatically.

## Optional: Remotion Studio and CLI
```bash
npm run studio                                   # open Remotion Studio
npx remotion render src/remotion/index.ts IslamicVideo out.mp4 --props=props.json
```
`props.json` has the same shape as `VideoProps` in `src/types.ts`.

## Project structure
```
server/index.ts              Express + @remotion/renderer (POST /api/render)
src/App.tsx                  Editor panel and live <Player> preview
src/defaultData.ts           Default template content
src/types.ts                 VideoProps, FPS, size constants
src/lib/timeline.ts          Paragraph splitting and scene timing
src/lib/image.ts             Image upload and downscaling
src/remotion/
  Root.tsx, index.ts         Composition registration (dynamic duration)
  IslamicVideo.tsx           Main composition: backdrop + scene sequence
  font.ts                    Inter font (Latin Extended covers Albanian ë ç)
  scenes/                    IntroScene, QuestionScene, ContentScene
  components/                Backdrop, Shape, RadialPattern, KineticText,
                             ScholarImage, SceneFade
```

## Customising
- **Timing:** `buildTimeline` in `src/lib/timeline.ts` (scene weights, minimum scene length).
- **Transitions:** `SceneFade.tsx` (blur, fade and slide length).
- **Layouts for content scenes:** the `LAYOUTS` array in `ContentScene.tsx`.
- **Shapes and background lines:** `Shape.tsx` and `Backdrop.tsx`.
- **Colours** are props (`bgColor`, `inkColor`), so they can be changed in the editor or in `props.json`.

## Notes
- Remotion compositions use inline styles; Tailwind is used only by the editor UI.
- The Remotion license is free for individuals and small teams but requires a company license for larger ones. See remotion.dev/license.
