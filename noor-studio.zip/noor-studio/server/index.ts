import express from 'express';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs';
import { bundle } from '@remotion/bundler';
import { renderMedia, selectComposition } from '@remotion/renderer';

const app = express();
app.use(express.json({ limit: '200mb' }));

let bundled: Promise<string> | null = null;
const getBundle = () => (bundled ??= bundle({ entryPoint: path.resolve('src/remotion/index.ts') }));

app.post('/api/render', async (req, res) => {
  const out = path.join(os.tmpdir(), `noor-${Date.now()}.mp4`);
  try {
    const serveUrl = await getBundle();
    const inputProps = req.body;
    const composition = await selectComposition({ serveUrl, id: 'IslamicVideo', inputProps });
    await renderMedia({ composition, serveUrl, codec: 'h264', outputLocation: out, inputProps });
    res.download(out, 'islamic-video.mp4', () => fs.unlink(out, () => {}));
  } catch (e) {
    bundled = null; // allow a fresh bundle next time
    console.error(e);
    res.status(500).json({ error: e instanceof Error ? e.message : String(e) });
  }
});

app.listen(3001, () => console.log('Render server on http://localhost:3001'));
